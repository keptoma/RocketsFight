﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RocketsFight
{
    public partial class Form2 : Form
    {
        public int count = 0;
        public int lives = 5;
        Random rand = new Random();
        

        public Form2()
        {
          
            InitializeComponent();

            this.KeyDown += new KeyEventHandler(Form2_KeyDown);
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label3.Visible = false;
            bullet1.Visible = false;
            timer1.Start();

        }

      
        private void Form2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A)
            {
                if(goodrocket.Left<12)
                {
                    goodrocket.Left -= 0;
                }
                else
                goodrocket.Left -= 10;
            }
            else if (e.KeyCode == Keys.D)
            {

                goodrocket.Left += 10;
            }

            // bullet 
            else if (e.KeyCode == Keys.Space)
            {
              
                bullet1.Location = goodrocket.Location;
                timer2.Start();
               
           }
            

        }
        //badrocket move and bounce
        private void timer1_Tick(object sender, EventArgs e)
        {

            badrocket.Top += 10;
            badrocket.Visible = true;
            if (badrocket.Top > 421)
            {
                badrocket.Location = new Point(rand.Next(100, 700), 12);
            }
            if (badrocket.Bounds.IntersectsWith(bullet1.Bounds))
            {

                count++;
                label1.Text ="Count: " + Convert.ToString(count);
                badrocket.Location = new Point(rand.Next(100, 700), 12);
                if (count>=20)
                {
                    timer1.Stop();
                    timer2.Stop();
                    label3.Visible = true;
                    label3.Text = "You Win!!!";
                }
            }

            if (badrocket.Bounds.IntersectsWith(goodrocket.Bounds))
            {

                lives--;
                label2.Text = "Lives: " + Convert.ToString(lives);
                badrocket.Location = new Point(rand.Next(100, 700), 12);

                if (lives <= 0)
                {
                    timer1.Stop();
                    timer2.Stop();
                    label3.Visible = true;
                    label3.Text = "You Lose";
                }
            }

           
        }
    
       //bullet_timer
        private void timer2_Tick(object sender, EventArgs e)
        {
            bullet1.Visible = true;
            bullet1.Top -= 10;

            if(bullet1.Top<-46)
            {
                bullet1.Location = goodrocket.Location;
                bullet1.Visible = false;
                timer2.Start();
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {

          //  bullet2.Visible = true;
           // bullet2.Top -= 10;
        }

       

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }


}









   